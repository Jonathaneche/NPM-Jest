Primer paso: Configuración de Jest

1. Asegúrate de tener Jest instalado en tu proyecto. Puedes instalarlo ejecutando el siguiente comando en tu terminal:

npm install --save-dev jest

2. Modificar el archivo packege.json

"scripts": {
"test": "jest"
},

2. Crea un archivo de configuración para Jest. Puedes llamarlo jest.config.js y agregar lo siguiente:

module.exports = {
testEnvironment: 'jsdom',
};

3. Crea un archivo llamado formulario.test.js para escribir tus pruebas. Asegúrate de que el nombre del archivo termine con .test.js para que Jest lo reconozca automáticamente

4. Dentro de formulario.test.js, importa las funciones o componentes que necesitas probar y configura el entorno de prueba. Por ejemplo:

---

import { validarNombre, validarCorreo } from './formulario';

// Prueba de la función validarNombre
describe('validarNombre', () => {
test('debería devolver verdadero para un nombre válido', () => {
expect(validarNombre('John Doe')).toBe(true);
});

test('debería devolver falso para un nombre vacío', () => {
expect(validarNombre('')).toBe(false);
});
});

// Prueba de la función validarCorreo
describe('validarCorreo', () => {
test('debería devolver verdadero para un correo electrónico válido', () => {
expect(validarCorreo('correo@example.com')).toBe(true);
});

test('debería devolver falso para un correo electrónico inválido', () => {
expect(validarCorreo('correo@example')).toBe(false);
});
});

---

## Al Descargar desde el repositorio:

npm install
