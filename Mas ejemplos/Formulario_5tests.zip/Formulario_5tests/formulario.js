const form = document.getElementById("myForm");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const resultMessage = document.getElementById("resultMessage");

function validarNombre(nombre) {
  return nombre.trim().length > 0;
}

function validarCorreo(correo) {
  const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regexCorreo.test(correo);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = nameInput.value;
  const email = emailInput.value;

  if (!validarNombre(name)) {
    resultMessage.textContent = "Por favor, ingrese un nombre válido.";
    resultMessage.style.color = "red";

    return;
  }

  if (!validarCorreo(email)) {
    resultMessage.textContent =
      "Por favor, ingrese un correo electrónico válido.";
    resultMessage.style.color = "red";
    return;
  }

  const message = `Gracias por enviar el formulario, ${name} (${email})!`;
  resultMessage.textContent = message;
  resultMessage.style.color = "green";
  nameInput.value = "";
  emailInput.value = "";
});
