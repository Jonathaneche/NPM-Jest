// Importa la librería necesaria para ejecutar las pruebas
const { JSDOM } = require("jsdom");

// Lee el archivo HTML y el archivo JavaScript
const fs = require("fs");
const html = fs.readFileSync("./formulario.html", "utf-8");
const js = fs.readFileSync("./formulario.js", "utf-8");

// Configura el entorno de JSDOM
const dom = new JSDOM(html, { runScripts: "dangerously" });
const { window } = dom;

// Configura Jest
global.document = window.document;
global.window = window;

// Ejecuta el archivo JavaScript
eval(js);

test("Prueba de envío del formulario con nombre y correo válidos", () => {
  const nameInput = document.getElementById("nameInput");
  const emailInput = document.getElementById("emailInput");
  const form = document.getElementById("myForm");
  const resultMessage = document.getElementById("resultMessage");

  nameInput.value = "John Doe";
  emailInput.value = "johndoe@example.com";
  form.dispatchEvent(new window.Event("submit"));

  expect(resultMessage.textContent).toBe(
    "Gracias por enviar el formulario, John Doe (johndoe@example.com)!"
  );
});

test("Prueba de envío del formulario con nombre inválido", () => {
  const nameInput = document.getElementById("nameInput");
  const emailInput = document.getElementById("emailInput");
  const form = document.getElementById("myForm");
  const resultMessage = document.getElementById("resultMessage");

  nameInput.value = "";
  emailInput.value = "johndoe@example.com";
  form.dispatchEvent(new window.Event("submit"));

  expect(resultMessage.textContent).toBe(
    "Por favor, ingrese un nombre válido."
  );
});

test("Prueba de envío del formulario con correo inválido", () => {
  const nameInput = document.getElementById("nameInput");
  const emailInput = document.getElementById("emailInput");
  const form = document.getElementById("myForm");
  const resultMessage = document.getElementById("resultMessage");

  nameInput.value = "John Doe";
  emailInput.value = "correo.invalido";
  form.dispatchEvent(new window.Event("submit"));

  expect(resultMessage.textContent).toBe(
    "Por favor, ingrese un correo electrónico válido."
  );
});

test("Prueba de existencia de un elemento", () => {
  const element = document.getElementById("titulo");

  expect(element).toBeDefined();
});
