// Importar las funciones a probar
import { sumar, restar, multiplicar, dividir } from "../calculadora";

describe("Pruebas en calculadora sencilla", () => {
  test("Sumar dos números", () => {
    expect(sumar(2, 3)).toBe(5);
  });

  test("Restar dos números", () => {
    expect(restar(5, 7)).toBe(-2);
  });

  test("Multiplicar dos números", () => {
    expect(multiplicar(2, 3)).toBe(6);
  });
});

test("Dividir dos números", () => {
  expect(dividir(2, 2)).toBe(1);
});
